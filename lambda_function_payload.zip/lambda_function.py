import boto3
import json
import logging
import os
import datetime
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from dateutil.tz import tzlocal

# Define AWS region and service
region = 'ap-south-1'
service = 'es'

# Define OpenSearch domain name
domain_name = 'systlabs'

# Slack webhook URL
HOOK_URL = "https://hooks.slack.com/services/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"

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # Initialize the OpenSearch client
    client = boto3.client(service, region_name=region)
    
    # Get the OpenSearch cluster status
    response = client.describe_elasticsearch_domain(DomainName=domain_name)
    
    # Log the response to understand its structure
    logger.info('Response: %s' % json.dumps(response, default=str))
    
    # Extract cluster status
    try:
        cluster_status = response['DomainStatus']['DomainProcessingStatus']
    except KeyError:
        logger.error("Status key not found in response: %s", response)
        return
    
    # Check if the cluster status is 'processing' (red state) or 'active' (green state)
    if cluster_status.lower() in ['processing', 'active']:
        # Convert UTC time to Indian Standard Time
        now = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=5, minutes=30)
        fmt1 = now.strftime('%A, %B %d, %Y - %H:%M IST')
        logger.info('fmt1 = %s' % (fmt1))
        
        # Send notification to Slack channel
        slack_message = {
            'channel': "#cloudwatch",
            'text': f"OpenSearch cluster status: {cluster_status.upper()} @ {fmt1}"
        }

        req = Request(HOOK_URL, json.dumps(slack_message).encode('utf-8'))

        try:
            response = urlopen(req)
            response.read()
            logger.info("Message posted to %s", slack_message['channel'])

        except HTTPError as e:
            logger.error("Request failed: %d %s", e.code, e.reason)

        except URLError as e:
            logger.error("Server connection failed: %s", e.reason)
